function [Options] = Setup_Options_Fit_ME

%-----Fit Options-----
Options.FitMethod = 'Unconstrained-NelderMead';
% Options.FitMethod = 'Constrained-InteriorPoint';
    % Choose the fit method. Unconstrained with Nelder-Mead algorithm (see
    % reference file for fminsearch) or Constrained with Interior Point
    % algorithm (see reference file for fmincon). If you choose constrained
    % fit, make sure you specify constraint boundaries on the parameters.
  
% Options.GuessArray = 'Large';
Options.GuessArray = [150000, 6.5, 0];
    % Your initial guess (these will be defined in Setup_Rate_Constants)
    % If you are scanning more than one guess, have additional 
    % guesses in separate rows. 'Large' means you will set up a larger guess
    % scan in Setup_Guess_Scan, at the bottom of this file.    
    if strcmp(Options.GuessArray,'Large')
        Options = Setup_Guess_Scan(Options);
    end
    
Options.LowerBounds = [1000];
Options.UpperBounds = [1e11];
    % The lower and upper bounds on your fit parameters. Should be the same
    % size as your initial guess matrix. These values will only be used if
    % you are performing a constrained fit.

Options.LikelihoodMethod = 'KineticsAndEfficiencies';
    % This determines which likelihood function will be used. Don't change.

Options.KineticWeightConstant = 1;
    % Constant used in the log likelihood calculation to weight the
    % kinetic terms relative to the efficiencies.Set equal to 1 if you want
    % equal weighting. 

Options.NormalizeModelEfficiencies = 'n';
    % y or n. Normalize the efficiencies of the model to the first pH value
    % in the sequence when calculating the likelihood function. 
    
Options.DisplayFitNotes = 'n';
    % Display the output notes to the command line from the built in Matlab minimization
    % functions which are used.
    
%-----Experimental data options-----
Options.ExpDataFilename = strcat(pwd,'/DataToFit/WNVDataToFit_Updated.mat');
    % Path to experimental data file (.MAT) we will be fitting
Options.UseRelEfficiencies = 'y';
    % y or n. Whether or not to use relative experimental efficiencies,
    % normalizing to the value below 
Options.EffMax = .309;
    % 0.309 = efficiency of WNV data pH 5.0

%------Kinetic Solver Options-----
Options.pHValues = [5.0,5.25,5.5,5.75,6.0,6.25];
    % pH values you want to scan in the simulation
Options.TotalTime = 300;
    % Total time to evaluate, in seconds. Experimental data usually
    % collected for 340 seconds following pH drop. 
Options.NumberDataPoints = 300;
    % Number data points to evaluate
Options.Time = linspace(0,Options.TotalTime,Options.NumberDataPoints);
    % Time vector. Each time value will be evaluated to find the fraction fused.
 
%-------Equilibration Options------
Options.TotalTime_Eq = 0;%300;
    % Total time in equilibration.
Options.Time_Eq = linspace(0,Options.TotalTime_Eq,15);
    % Time vector for the equilibration
    
%----Other Options----
Options.DisplayFigures = 'y';
    % y or n. Whether or not to display any figures at all.
Options.Parallel = 'n';
    % Choose y if you are running multiple instances of Matlab as a crude
    % parallelization. This will split up the parameter scan according to your
    % input into Start_Kinetic_Schemer_ME.  
Options.Diagnostics = 'n';

%-----Legacy options, don't change----
    %-----Gating test options/parameters---
    % Options.LikelihoodMethod = 'Kinetics,GatedEfficiencies';
    Options.GatePHValues = [4.6, 6.6];
%     Options.GatePHValues = [5, 6];
    % The 2 pH values whose efficiencies (from the model) will be compared to
    % see if they pass the gate test 
    Options.GateValue =  0.4;
    % The minimum difference in efficiencies needed to pass the gate test
    Options.HighEffValueCutoff = 0.8;
    % The minimum efficiency that the lowest pH value must have in order for the gate test to be valid
    
end

function Options = Setup_Guess_Scan(Options)
    
% Define individual parameters that you want to scan initial guesses
    Params{1,1} = [ 1, 500, 1300, 5000, 10000];
     Params{1,2} = [6.8, 9];
     Params{1,3} = [6, 9];

% Enumerate all possible combinations of your defined parameters. Note that
% the number of combinations can get quite large quite quickly...
    Options.GuessArray = allcomb(Params{1,1:size(Params,2)});    
end