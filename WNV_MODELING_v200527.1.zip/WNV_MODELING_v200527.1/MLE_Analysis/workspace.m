
for i = 1:length(CDFData) - 1
    NumberFuse(i) = length(CDFData(i).SortedpHtoFList);
    NumberTotal(i) = round(NumberFuse(i)/(CDFData(i).EfficiencyBefore/0.191));
    NumberNot(i) = NumberTotal(i) - NumberFuse(i);
    Efficiency(i) = CDFData(i).EfficiencyBefore/0.191;
    
end

TotalEfficiency = sum(NumberFuse)/sum(NumberTotal)
AverageEfficiency = mean(Efficiency)

TotalConstant = sum(NumberNot)/sum(NumberFuse)
Constant = 10;
NewNumberFuse = Constant*NumberFuse;
NewTotal = NewNumberFuse + NumberNot;
NewEfficiency = NewNumberFuse./NewTotal;

NewTotalEfficiency = sum(NewNumberFuse)/sum(NewTotal)
NewAverageEfficiency = mean(NewEfficiency)