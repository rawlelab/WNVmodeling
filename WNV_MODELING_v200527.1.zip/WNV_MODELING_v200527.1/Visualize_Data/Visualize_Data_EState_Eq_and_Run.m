function Visualize_Data_EState_Eq_and_Run(varargin)
close all

OldStyle ='n';

% Identify the paths to the data you wish to analyze
    [DataFilenames,DefaultPathname] = Load_Data(varargin);
    
    Options.NumPlotsX = 6;
    Options.NumPlotsY = 3;
    Options.TotalNumPlots = Options.NumPlotsX * Options.NumPlotsY;
        % must be divisible by NumPlotsPerFile
    
% Create master window with subplots
    [FigureHandles] = Create_Master_Window(Options);
    
% Determine how many files are being analyzed
    if iscell(DataFilenames) %This lets us know if there is more than one file
        NumberOfFiles = length(DataFilenames);
    else
        NumberOfFiles = 1;
    end

% Define variables we will need
    NumPlotsPerFile = 2;
    NumPlotRounds = ceil(NumPlotsPerFile*NumberOfFiles/Options.TotalNumPlots);
    FileCounter = 1;
    
% Review plots round by round
    for b = 1:NumPlotRounds
        disp(strcat('Round-', num2str(b),'-of-', num2str(NumPlotRounds)))
        
        if b ~= NumPlotRounds
            CurrentFileRange = FileCounter:FileCounter - 1 + (Options.TotalNumPlots)/NumPlotsPerFile;
            FileCounter = max(CurrentFileRange) +1;
        else
            CurrentFileRange = FileCounter:NumberOfFiles;
            for d = length(CurrentFileRange)*NumPlotsPerFile + 1: Options.TotalNumPlots
                set(FigureHandles.MasterWindow,'CurrentAxes',FigureHandles.SubHandles(d));
                cla
            end
        end
        
        % Load and plot each file in the current range
        PlotCounter = 0;
        for i = CurrentFileRange
            PlotCounter = PlotCounter + 1;
            
            if NumberOfFiles > 1
               CurrDataFileName = DataFilenames{1,i};
            else
               CurrDataFileName = DataFilenames;
            end
            
            % Extract data that we will need
            CurrentFilePath = strcat(DefaultPathname,'/',CurrDataFileName);
            InputData = open(CurrentFilePath);
            DataToSave = InputData.DataToSave;
            NumberpHValues = length(DataToSave);
            CurrentParameters = DataToSave(1).CurrentParameters;
            if strcmp(OldStyle, 'y')
                PSetNumber = CurrDataFileName(end-7:end-4);
            else 
                PSetNumber = DataToSave(1).HelpfulInfo.PSetNumber;
            end
            LegendInfo = [];
            
            % Plot each pH value for the current parameter set
                set(FigureHandles.MasterWindow,'CurrentAxes',FigureHandles.SubHandles(PlotCounter))
                cla
                EfficiencyToPlot = [];
                
                for h = 1:NumberpHValues
                    pH = DataToSave(h).SimOutput.pH;
                    Nmin = DataToSave(h).CDFData.Nmin;
                    CumX = DataToSave(h).CDFData.CumX;
                    CumYNormalized = DataToSave(h).CDFData.CumYNormalized;
                    CumY = DataToSave(h).CDFData.CumY;
                        if strcmp(OldStyle, 'y')
                            NumberVirions = 500;
                            Efficiency = CumY(end)/NumberVirions*100;
                        else
                            NumberVirions = DataToSave(h).CDFData.NumberVirions;
                            Efficiency = DataToSave(h).CDFData.Efficiency;
                        end

%                     set(FigureHandles.MasterWindow,'CurrentAxes',FigureHandles.SubHandles(PlotCounter));
%                     hold on
%                     plot(CumX,CumYNormalized,'o')
%                     drawnow
% 
%                     LegendInfo{1,h} = strcat('pH=',num2str(pH),'; Eff=',num2str(Efficiency));
%                     pHToPlot(h) = pH;
%                     EfficiencyToPlot(h) = Efficiency;
                end

                
                
                
                SimOutput = DataToSave(1).SimOutput;
                %                      ^ # is the pH value
                    if strcmp(OldStyle, 'y')
                            NumberMonomers = 30;
                        else
                            NumberMonomers = DataToSave(h).HelpfulInfo.NumberMonomers;
                    end
                EData = SimOutput.EStateData.EStatesRecord;
                ETime = SimOutput.EStateData.TimeVector;
                StateSumData = [];

                for State = SimOutput.PossibleStates
                    StateData = floor(EData) == State;
                    StateSumData(State,1:length(ETime)) = sum(sum(StateData))./(NumberVirions*NumberMonomers);

                    set(FigureHandles.MasterWindow,'CurrentAxes',FigureHandles.SubHandles(PlotCounter));
                    hold on
                    plot(ETime,StateSumData(State,:))
                    drawnow

                    DLegend{1,State} = strcat('EState=',num2str(State));
                end
                
                
                
                % Add the legend and title
                set(FigureHandles.MasterWindow,'CurrentAxes',FigureHandles.SubHandles(PlotCounter));
                legend(LegendInfo,'Location','best');
%                 xlabel('Time');
                xlim([0 300])
%                 ylabel('Normalized Fusion');

                title(strcat('PSet ',num2str(PSetNumber),'; P=',num2str(CurrentParameters)))

            % Plot the equilibrium E state data (assume only one
            % equilibrium run) in the next window
                PlotCounter = PlotCounter + 1;
                set(FigureHandles.MasterWindow,'CurrentAxes',FigureHandles.SubHandles(PlotCounter))
                cla

                % Extract the equilibrium data we need
                SimOutput = DataToSave(h).SimOutput;
                if strcmp(OldStyle, 'y')
                    NumberMonomers = 30;
                else
                    NumberMonomers = DataToSave(h).HelpfulInfo.NumberMonomers;
                end
                EData = SimOutput.EStateData.EStatesRecord_Eq;
                ETime = SimOutput.EStateData.TimeVector_Eq;
                StateSumData = [];

                for State = SimOutput.PossibleStates
                    StateData = floor(EData) == State;
                    StateSumData(State,1:length(ETime)) = sum(sum(StateData))./(NumberVirions*NumberMonomers);

                    set(FigureHandles.MasterWindow,'CurrentAxes',FigureHandles.SubHandles(PlotCounter));
                    hold on
                    plot(ETime,StateSumData(State,:))
                    drawnow

                    %DLegend{1,State} = strcat('EState=',num2str(State));
                end

                % Add the legend and title
                %set(FigureHandles.MasterWindow,'CurrentAxes',FigureHandles.SubHandles(PlotCounter))
                %legend(DLegend,'Location','best');
%                 xlabel('Time');
%                 ylabel('EState Frequency');

            %Alternatively: plot the efficiency values
%            set(FigureHandles.MasterWindow,'CurrentAxes',FigureHandles.SubHandles(PlotCounter));
%            hold on
%            plot(pHToPlot,EfficiencyToPlot,'-o')
%            ylim([0 100])
%             axis([5 6.5 0 1])
%            drawnow

        end
        
        % Wait for user input to go to next round
        RerunThisRound = 'y';
        while RerunThisRound =='y'
            Prompts = {strcat(num2str(b),'/', num2str(NumPlotRounds),'; Enter To Continue')};
            DefaultInputs = {'Continue'};
            Heading = 'Type q to quit';
            UserAnswer = inputdlg(Prompts,Heading, 1, DefaultInputs, 'on');

            if isempty(UserAnswer)
                % There has been an error, re-run the last round to avoid crash
                RerunThisRound = 'y';
                
            elseif strcmp(UserAnswer{1,1},'q')
                disp('You Chose To Quit')
                ThisWillCauseError
            
            elseif strcmp(UserAnswer{1,1},'Continue')
                % move to next round
                RerunThisRound = 'n';            
            else
                % There has been an error, re-run the last round to avoid crash
                RerunThisRound = 'y';
                
            end
        end

    end

end

function [DataFilenames,DefaultPathname] = Load_Data(varargin)
        if length(varargin) == 1
            [DataFilenames, DefaultPathname] = uigetfile('*.mat','Select .mat files to be analyzed',...
                char(varargin{1}),'Multiselect', 'on');
        else
            [DataFilenames, DefaultPathname] = uigetfile('*.mat','Select .mat files to be analyzed', 'Multiselect', 'on');
        end
end